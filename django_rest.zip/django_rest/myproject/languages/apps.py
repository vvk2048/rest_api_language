from django.apps import AppConfig


class LanguagesConfig(AppConfig):
    name = 'languages'
